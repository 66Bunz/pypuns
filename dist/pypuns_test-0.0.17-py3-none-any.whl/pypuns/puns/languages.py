import json

italian = json.load(open('it.json'))
english = json.load(open('en.json'))
# german = json.load(open('de.json'))
# test=json.load(open('it'))

all_languages = {
    "it": italian,
    "en": english,
}