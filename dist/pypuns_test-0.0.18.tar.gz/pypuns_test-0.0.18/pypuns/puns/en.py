
blackhumor = [
    "Give a man a match, and he'll be warm for a few hours. Set a man on fire, and he will be warm for the rest of his life",
    "My wife and I have reached the difficult decision that we do not want children. If anybody does, please just send me your contact details and we can drop them off tomorrow",
    "I have a fish that can breakdance! Only for 20 seconds though, and only once",
    "Give a man a plane ticket and he flies for the day. Push him out of the plane at 3,000 feet and he'll fly for the rest of his life",
    "I was in Russia listening to a stand-up comedian making fun of Putin. The jokes weren't that good, but I liked the execution",
    "Why can't orphans play baseball? They don't know where home is",
    "I started crying when dad was cutting onions. Onions was such a good dog"
]

tongue_twister = [
    "I scream, you scream, we all scream for ice cream",
    "I saw Susie sitting in a shoeshine shop",
    "Can you can a can as a canner can can a can?"
]

puns = [
    "Why did Adele cross the road? To say hello from the other side",
    "What kind of concert only costs 45 cents? A 50 Cent concert featuring Nickelback",
    "What do you call a fake noodle? An impasta",
    "To the guy who invented zero, thanks for nothing",
    "So what if I don’t know what apocalypse means? It’s not the end of the world!",
    "I've got a lot of unemployement jokes, but none of them would work",
    "How di you call a Mexican who lost his car? Carloss",
    "What's the difference between a fish and a guitar? You can't tuna fish"
]

# ------------------------------------------------------------------------------

en_puns = {
    'blackhumor': blackhumor,
    'tongue_twister': tongue_twister,
    'puns': puns,
    'all': blackhumor + tongue_twister + puns
}