
blackhumor = [
    "È vero che non seguo il ddl zan: io per strada li picchio i gay (cit. Cata)",
    "Dove sono seduti gli ebrei in una macchina? Nel posacenere",
    "Sara sta andando sull'altalena, ma ad un certo punto cade. Perchè? Perchè non ha le braccia. Toc toc. Chi è? Di sicuro non Sara.",
    "Una ragazza va all'interrogazione sui diritti delle donne, ma fa scena muta. Prende 10.",
    "Ad una bambina in Africa sono arrivate le medicine contro l'ebola, ma dietro c'è scritto \"da consumare dopo i pasti\"",
    "Qual è la differenza tra un depresso e la pizza? Che la pizza non si taglia da sola",
    "Perchè in una partita a scacchi New York perde? Perchè le mancano le due torri",
    "Sai cos'hanno di speciale le barzellette sui bambini morti? Che non diventano mai vecchie",
    "Qual è la parte più bianca di un africano? Il padrone"
]

tongue_twister = [
    "Trentatrè trentini entrarono a Treno tutti e trentatrè trotterellando",
    "Tre tigri contro tre tigri",
    "Se l'arcivescovo di Costantinopoli si disarcivescoviscostantinopolizzasse, tu ti disarcivescoviscostantinopolizzeresti come si è disarcivescoviscostantinopolizzato l'arcivescovo di Costantinopoli?"
]

puns = [
    "Cesare il popolo chiede sesterzi! Nono vado dritto",
    "Chi può intendere intenda, gli altri in camper",
    "Piacere, Gofredo. Anche a mi ma resisto",
    "Due ciechi si incontrano per strada e se le suonano di santa ragione. Non si potevano vedere",
    "Come fai a far parlare uno spago? Basta dargli corda",
    "Un elicottero cade in un cimitero. I carabinieri hanno già recuperato 300 corpi"
]

# ------------------------------------------------------------------------------

it_puns = {
    'blackhumor': blackhumor,
    'tongue_twister': tongue_twister,
    'puns': puns,
    'all': blackhumor + tongue_twister + puns
}