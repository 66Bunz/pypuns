from .en import en_puns
from .it import it_puns

all_languages = {
    'en': en_puns,
    'it': it_puns,
}